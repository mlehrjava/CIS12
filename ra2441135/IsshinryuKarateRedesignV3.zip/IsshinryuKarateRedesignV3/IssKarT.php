<?php # IssKarT.php - Terminology
// This page displays a list of Terms commonly used in Isshinryu Karate.


// Start Session Before Sending Anything to Server
session_start();
$page_title = 'Isshinryu Terminology';
$bgImg = 'http://behance.vo.llnwd.net/profiles2/203106/projects/615767/ceaf32770934a92745fec8552e7f7051.png';
include ('IssKarHeader.inc.html');
include ('IssKarNavbar.inc.html');
?>
<h1 style="text-align:center;">Terminology</h1>
        <p style="margin:0px 50px 0px 50px;">The following Translations were borrowed with the permission of a great Web Site, I requested permission to use the "Translations" and received permission with the request that I would give credit to their site... Well as we were retyping and editing and adding and subtracting. I lost the Site to whom I owe the credit for this page of Translations. First, my apologies. Secondly, if anyone that reads this page can please advise me of the site I will do the following... 1. Apologize and 2. Give proper credit where it is due.</p>

<p style="text-align:right; margin-right:70px;">Sincerely,  With Respect,</p>  
<p style="text-align:right; margin-right:70px;">Arnold R Sandubrae</p>
        <iframe class="termIframe" width="90%" height="74.5%" frameborder="5" scrolling="auto" marginheight="0" marginwidth="0" src="IssKarTerms.php"></iframe>
<?php include('IssKarFooter.inc.html'); ?>