Instructions for using files in IsshinryuKarateRedesign by Ricky Adams

1. Extract Files to C:\xampp\htdocs.

2. Import "isskar.sql" using "MySQL WorkBench"

3. Make sure "Xammp's" APACHE and MySQL modules are running.

4. All .php files must be opened using the url: localhost/isshinryukarateredesign/
